#!/usr/bin/env bash
# collect.sh - dump all files needed to debug the site.yml / cluster_join failure
set -u
cd "$(dirname "$0")" || exit 1

hr()  { printf '\n========== %s ==========\n' "$*"; }
dump() {
	  local f="$1"
	    hr "FILE: $f"
	      if [[ -f "$f" ]]; then
		          cat -- "$f"
			    else
				        echo "(MISSING)"
					  fi
				  }

			  dump ansible.cfg
			  dump inventory/hosts.ini
			  dump inventory/group_vars/all.yml

			  dump playbooks/site.yml
			  dump playbooks/site.yml.bak
			  dump playbooks/cleanup.yml
			  dump playbooks/install_flannel.yml
			  dump playbooks/join_master2.yml

			  dump roles/cluster_init/tasks/main.yml
			  dump roles/cluster_init/templates/kubeadm-config.yaml.j2

			  dump roles/cluster_join/tasks/main.yml
			  dump roles/cluster_join/tasks/main.yml.bak-before-join-fix
			  dump roles/cluster_join/tasks/main.yml.bak-kubeadm-config-rbac
			  dump roles/cluster_join/tasks/main.yml.bak-rolebinding-fix

			  dump roles/containerd/tasks/main.yml
			  dump roles/containerd/handlers/main.yml
			  dump roles/kubernetes_binaries/tasks/main.yml
			  dump roles/kubernetes_binaries/handlers/main.yml
			  dump roles/system_prep/tasks/main.yml
			  dump roles/system_prep/handlers/main.yml
			  dump roles/cni_plugins/tasks/main.yml
			  dump roles/cni_flannel/tasks/main.yml
			  dump roles/verify/tasks/main.yml

			  hr "GREP: co-certs / co_certs / certificate / upload-certs across project"
			  grep -RIn --exclude-dir=.git \
				    -e 'co-certs' -e 'co_certs' -e 'upload-certs' -e 'certificate[-_]key' \
				      . 2>/dev/null || echo "(no matches)"

			  hr "GREP: every 'kubeadm init' / 'kubeadm join' invocation"
			  grep -RIn --exclude-dir=.git \
				    -e 'kubeadm init' -e 'kubeadm join' -e 'kubeadm ' \
				      roles/ playbooks/ 2>/dev/null || echo "(no matches)"

			  hr "GREP: definition of any variable used near the kubeadm command"
			  grep -RIn --exclude-dir=.git -E '^\s*[A-Za-z_][A-Za-z0-9_]*\s*:' \
				    inventory/group_vars/ roles/ 2>/dev/null | head -200

			  hr "ROOT-LEVEL BINARIES: what are they?"
			  for f in kubeadm kubectl crictl echo grep systemctl; do
				    if [[ -e "$f" ]]; then
					        printf '%-10s : ' "$f"
						    file -b -- "$f"
						        ls -la -- "$f"
							  else
								      printf '%-10s : (absent)\n' "$f"
								        fi
								done

								hr "ENV: which kubeadm resolves to"
								command -v kubeadm || echo "(kubeadm not on PATH)"
								kubeadm version -o short 2>/dev/null || true

								hr "TREE (dirs only, 3 levels, for context)"
								find . -maxdepth 3 -type d -not -path '*/.git*' | sort

								echo
								echo "===== END OF COLLECTION ====="

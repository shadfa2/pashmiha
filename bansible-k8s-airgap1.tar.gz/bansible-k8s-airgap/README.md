# Kubernetes Air-Gap Ansible (refactored)

This project is a clean, idempotent baseline for installing Kubernetes **v1.30.14** on Rocky/RHEL-family nodes with containerd **1.7.13** in an air-gapped network. It is based on the uploaded project but removes duplicate/experimental playbooks from the core install path and fixes major path, version, CRI, and HA join issues.

## Main changes

- One supported entry point: `playbooks/site.yml`; roles separate system preparation, containerd, Kubernetes binaries, cluster initialization, joining, CNI, and verification.
- Fixed mismatch between inventory `192.168.30.x` and previously hard-coded `192.168.56.x` API address.
- Uses consistent `kuber_masters`, `kuber_workers`, and `kuber_cluster` inventory groups.
- No remote path assumptions for controller-side role files; offline files are staged from `offline_package/`.
- Correct containerd config is generated from `containerd config default`, preserving the CRI plugin and setting systemd cgroups and the expected pause image.
- Installs RPMs only from local staged paths, without `--skip-broken` or `rpm --nodeps` fallback.
- Imports image archives on **every node**, not just the first master, and validates required kubeadm images before init.
- Uses `kubeadm init --upload-certs`; additional control-plane nodes join with the certificate key and discovery token/hash.
- Installs ingress-nginx **after** all inventory nodes have joined and passed the Ready check, so it does not block node joins when only the tainted first control-plane is registered.
- Collects ingress pod status, Deployment details, namespace events, and controller logs automatically if the ingress rollout fails.
- Joining is idempotently skipped when `/etc/kubernetes/kubelet.conf` already exists.
- Destructive cleanup is isolated in `playbooks/cleanup.yml`, prompts for `DESTROY`, and is never run by `site.yml`.
- Removed old hard-coded DNS edits, broad iptables flushes, duplicate setup/cleanup playbooks, and unrelated experimental Rook-Ceph install from the core path.

## Important HA requirement

There are two control-plane nodes in the sample inventory, but the default `control_plane_endpoint` is `192.168.30.227:6443` only as a bootstrap example. This is **not highly available** if master1 fails. For a real HA control plane, configure a stable VIP or load-balancer DNS endpoint in `inventory/group_vars/all.yml` and route TCP/6443 to both masters before installation. Ensure that endpoint is included in the API server certificate SANs.

## Inventory and variables

Edit `inventory/hosts.ini` for your real node names, SSH users, and IP addresses. Edit `inventory/group_vars/all.yml` to set the Kubernetes/containerd versions, pod/service CIDRs, image repository, stable API endpoint, and offline asset paths. Keep Kubernetes minor versions aligned across `kubeadm`, `kubelet`, `kubectl`, and image archives.

## Offline assets

See `offline_package/README/README.txt`. Required assets are deliberately not bundled in this archive because the uploaded project did not contain the binaries, RPMs, image archives, or Flannel manifest. Put the actual files into the versioned directories before running installation. The playbook fails early if required files are missing.

## Preflight

From the project root on the Ansible controller:

```bash
ansible --version
ansible-inventory --graph
ansible -m ping kuber_cluster
ansible-playbook playbooks/site.yml --syntax-check
ansible-playbook playbooks/site.yml --list-hosts
```

The core project uses `ansible.builtin` modules and does not require extra Ansible collections. Use a currently maintained Ansible version on the controller.

## Install

```bash
cd /path/to/ansible-k8s-airgap-fixed
ansible-playbook playbooks/site.yml --ask-become-pass
```

If `kuber` has working passwordless sudo, omit `--ask-become-pass`. Run with `-v` or `-vv` for diagnostics. `site.yml` does not reset an existing cluster.

## Cleanup (destructive, explicit)

Only for a cluster you intentionally want to reset:

```bash
ansible-playbook playbooks/cleanup.yml --ask-become-pass
```

At the prompt, type exactly `DESTROY`. It removes local etcd data and Kubernetes node configuration from every selected node. Review inventory first. It does not remove containerd or the offline package cache.

## Troubleshooting

- Containerd: `systemctl status containerd --no-pager -l`; `journalctl -u containerd -b --no-pager`; `crictl info`.
- Kubelet: `systemctl status kubelet --no-pager -l`; `journalctl -u kubelet -b -n 200 --no-pager`.
- Init logs: run `kubeadm init` output from Ansible and inspect `journalctl -u kubelet` on first master.
- Image issues: `sudo crictl images` or `sudo ctr -n k8s.io images list`; compare the exact image reference in `offline_package/cni/ingress-nginx/<version>/deploy.yaml` with the imported image name and tag. Air-gapped nodes cannot pull an image that is absent locally unless a reachable internal registry is configured.
- Ingress scheduling: `kubectl -n ingress-nginx get pods -o wide` and `kubectl -n ingress-nginx get events --sort-by=.lastTimestamp`. If events say `untolerated taint ... control-plane`, verify the worker node joined and is Ready. This project's intended multi-node design schedules ingress on a worker; it does not remove the control-plane taint globally.
- If `site.yml` stops at ingress, ensure the install order is correct: node joins and the `verify` role run before `Install ingress-nginx controller`. This prevents an ingress scheduling issue from preventing the join tasks from running.
- CNI: `kubectl get pods -A -o wide`; `kubectl -n kube-flannel logs daemonset/kube-flannel-ds`.

## Limitations to validate in a lab

The project cannot verify the contents of your offline image tarballs or RPM dependency closure. The exact image set depends on the kubeadm version and the pinned Flannel manifest. Test on disposable VMs with the same Rocky/RHEL release and architecture before production use. The API endpoint must be configured to suit your network; a two-master inventory alone does not create HA.
